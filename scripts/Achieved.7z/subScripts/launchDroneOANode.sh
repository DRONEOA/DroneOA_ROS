#!/bin/bash
# Start a droneoa_ros node
source ~/ardupilot_ws/devel/setup.bash
rosrun droneoa_ros droneoa_ros