#!/bin/bash
# Start a SITL ArduCopter
sim_vehicle.py -v ArduCopter -L KSFO --map --console